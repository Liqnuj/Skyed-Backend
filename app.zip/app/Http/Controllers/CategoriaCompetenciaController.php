<?php

namespace App\Http\Controllers;

use App\Models\CategoriaCompetencia;
use App\Models\EventoDeportivo;
use App\Http\Resources\CategoriaCompetenciaResource;
use App\Http\Resources\EventoDeportivoResource;
use Illuminate\Http\Request;

class CategoriaCompetenciaController extends Controller
{
        public function index(Request $request, int $eventoId)
    {
        $evento = EventoDeportivo::find($eventoId);

        if (!$evento) {
            return response()->json([
                'message' => 'Evento no encontrado'
            ], 404);
        }

        $categorias = CategoriaCompetencia::where('id_e', $eventoId)
            ->paginate($this->perPage($request));

        // FIX: la respuesta no incluía la clave "evento" (solo las
        // categorías), aunque el propio test de este endpoint
        // (tests/Feature/CategoriaCompetenciaTest.php) y el patrón ya
        // usado en InscripcionController::index esperan ambas claves.
        return response()->json([
            'evento' => new EventoDeportivoResource($evento),
            'categorias' => CategoriaCompetenciaResource::collection($categorias),
        ]);
    }
    
    public function store(Request $request, int $eventoId)
    {
        $evento = EventoDeportivo::find($eventoId);

        if (!$evento) {
            return response()->json([
                'message' => 'Evento no encontrado'
            ], 404);
        }

        $validated = $request->validate([
            'nombre_cc' => 'required|string|max:50',

            'edad_minima_cc' => 'nullable|integer|min:0',

            'edad_maxima_cc' => 'nullable|integer|min:0|gte:edad_minima_cc',

            'genero_cc' => 'nullable|in:masculino,femenino,mixto',

            'distancia_cc' => 'nullable|string|max:45',

            'descripcion_cc' => 'nullable|string|max:255',
        ]);

        $validated['id_e'] = $eventoId;

        $categoria = CategoriaCompetencia::create($validated);

        return response()->json([
            'message' => 'Categoría creada correctamente',
            'categoria' => new CategoriaCompetenciaResource($categoria)
        ], 201);
    }

    public function show(int $id)
    {
        $categoria = CategoriaCompetencia::with('evento')->find($id);

        if (!$categoria) {
            return response()->json([
                'message' => 'Categoría no encontrada'
            ], 404);
        }

        return response()->json([
            'categoria' => new CategoriaCompetenciaResource($categoria)
        ]);
    }

    public function update(Request $request, $id)
    {
        $categoria = CategoriaCompetencia::find($id);

        if (!$categoria) {
            return response()->json([
                'message' => 'Categoría no encontrada'
            ], 404);
        }

        $validated = $request->validate([
            'nombre_cc' => 'sometimes|string|max:50',

            'edad_minima_cc' => 'sometimes|integer|min:0',

            'edad_maxima_cc' => 'sometimes|integer|min:0|gte:edad_minima_cc',

            'genero_cc' => 'sometimes|in:masculino,femenino,mixto',

            'distancia_cc' => 'sometimes|string|max:45',

            'descripcion_cc' => 'sometimes|string|max:255',
        ]);

        $categoria->update($validated);

        return response()->json([
            'message' => 'Categoría actualizada correctamente',
            'categoria' => new CategoriaCompetenciaResource($categoria->fresh())
        ]);
    }

    public function destroy($id)
    {
        $categoria = CategoriaCompetencia::find($id);

        if (!$categoria) {
            return response()->json([
                'message' => 'Categoría no encontrada'
            ], 404);
        }

        // Verificar si la categoría tiene resultados asociados
        if ($categoria->resultados()->exists()) {
            return response()->json([
                'message' => 'No se puede eliminar la categoría porque tiene resultados asociados'
            ], 409);
        }

        $categoria->delete();

        return response()->json([
            'message' => 'Categoría eliminada correctamente'
        ]);
    }
}